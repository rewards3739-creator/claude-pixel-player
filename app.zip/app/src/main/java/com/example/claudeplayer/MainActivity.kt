package com.example.claudeplayer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private val h = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            logView.text = PlayerService.logText
            h.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 80, 40, 40)

        val title = TextView(this)
        title.text = "Claude Player"
        title.textSize = 26f
        root.addView(title)

        val key = EditText(this)
        key.hint = "Anthropic API key (sk-ant-...)"
        key.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        key.setText(p.getString("key", ""))
        root.addView(key)

        val model = EditText(this)
        model.hint = "Model (blank = claude-sonnet-5-5)"
        model.setText(p.getString("model", ""))
        root.addView(model)

        val dry = CheckBox(this)
        dry.text = "Dry run (think but don't tap)"
        dry.isChecked = p.getBoolean("dry", false)
        root.addView(dry)

        val b1 = Button(this)
        b1.text = "1. Turn on Claude Player in Accessibility"
        b1.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(b1)

        val b2 = Button(this)
        b2.text = "2. START (then open your game)"
        b2.setOnClickListener {
            p.edit().putString("key", key.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .putBoolean("dry", dry.isChecked).apply()
            val s = PlayerService.instance
            if (s == null) {
                Toast.makeText(this, "Turn on Claude Player in Accessibility first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                s.start()
                Toast.makeText(this, "Started. Switch to your game now.", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(b2)

        val b3 = Button(this)
        b3.text = "STOP"
        b3.setOnClickListener { PlayerService.instance?.stop() }
        root.addView(b3)

        logView = TextView(this)
        logView.textSize = 12f
        root.addView(logView)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); h.post(refresh) }
    override fun onPause() { super.onPause(); h.removeCallbacks(refresh) }
}
