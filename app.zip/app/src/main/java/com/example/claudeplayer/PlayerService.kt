package com.example.claudeplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class PlayerService : AccessibilityService() {

    companion object {
        @Volatile var instance: PlayerService? = null
        @Volatile var logText: String = "Not started."
        const val SEND_WIDTH = 540
        const val SYSTEM_PROMPT = """You are playing a mobile puzzle game (Pixel Flow style) by looking at screenshots and tapping.
RULES: The framed picture is made of colored pixel blocks. Colored "pig" shooters on the conveyor belt shoot blocks of THEIR OWN color. Each pig's number = its ammo. Pigs wait in a grid at the bottom; tap a pig that is NOT covered by another pig (front-most, fully visible) to send it onto the belt. The belt holds limited pigs (e.g. 5/5); if full, wait.
STRATEGY: pick pigs whose color matches blocks exposed on the outer edge of the picture; prefer enough ammo to clear a region; do not waste belt slots on colors with nothing exposed.
SCREENS: menu with big yellow Play -> tap Play. Win/Continue/Next -> tap it. Fail -> free retry/close, never pay. Popups -> close with X / No thanks. Never watch ads on purpose.
NEVER tap anything that costs coins or money: plus buttons, bottom power-up buttons, No Ads, shop, gift offers.
Answer by calling the act tool. Coordinates are pixels of the image shown (origin top-left); tap the center of the target. If nothing useful can be done now, action wait."""
    }

    private val ui = Handler(Looper.getMainLooper())
    private var overlay: TextView? = null
    @Volatile private var running = false
    private val exec = Executors.newSingleThreadExecutor()
    private val logs = ArrayList<String>()

    override fun onServiceConnected() {
        instance = this
        addOverlay()
        log("Accessibility is on. Open the app and tap START.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        instance = null
        ui.post { removeOverlay() }
        return super.onUnbind(intent)
    }

    private fun addOverlay() {
        ui.post {
            if (overlay != null) return@post
            val tv = TextView(this)
            tv.setTextColor(Color.WHITE)
            tv.setBackgroundColor(Color.argb(204, 0, 0, 0))
            tv.textSize = 11f
            tv.setPadding(16, 8, 16, 8)
            tv.text = "Claude Player ready"
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(tv, lp)
            overlay = tv
        }
    }

    private fun removeOverlay() {
        try {
            overlay?.let { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (e: Exception) {}
        overlay = null
    }

    private fun log(msg: String) {
        synchronized(logs) {
            logs.add(msg)
            while (logs.size > 40) logs.removeAt(0)
            logText = logs.reversed().joinToString("\n\n")
        }
        ui.post { overlay?.text = msg.take(240) }
    }

    fun start() {
        if (running) return
        running = true
        Thread { loop() }.start()
    }

    fun stop() {
        running = false
        log("Stopped.")
    }

    private fun capture(): Bitmap? {
        ui.post { overlay?.visibility = View.INVISIBLE }
        Thread.sleep(250)
        var result: Bitmap? = null
        val latch = CountDownLatch(1)
        takeScreenshot(Display.DEFAULT_DISPLAY, exec, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(s: AccessibilityService.ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(s.hardwareBuffer, s.colorSpace)
                    result = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    s.hardwareBuffer.close()
                } catch (e: Exception) {}
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(5, TimeUnit.SECONDS)
        ui.post { overlay?.visibility = View.VISIBLE }
        return result
    }

    private fun tap(x: Float, y: Float) {
        val path = Path()
        path.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        val latch = CountDownLatch(1)
        dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { latch.countDown() }
            override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(2, TimeUnit.SECONDS)
    }

    private fun toolJson(): JSONObject {
        val props = JSONObject()
            .put("screen_state", JSONObject().put("type", "string")
                .put("enum", JSONArray(listOf("menu", "gameplay", "popup", "win", "fail", "loading", "unknown"))))
            .put("observation", JSONObject().put("type", "string"))
            .put("reasoning", JSONObject().put("type", "string"))
            .put("action", JSONObject().put("type", "string").put("enum", JSONArray(listOf("tap", "wait"))))
            .put("x", JSONObject().put("type", "integer"))
            .put("y", JSONObject().put("type", "integer"))
        return JSONObject()
            .put("name", "act")
            .put("description", "Report what you see and choose the next action.")
            .put("input_schema", JSONObject().put("type", "object").put("properties", props)
                .put("required", JSONArray(listOf("screen_state", "observation", "reasoning", "action"))))
    }

    private fun ask(key: String, model: String, b64: String, note: String): JSONObject {
        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source", JSONObject()
                .put("type", "base64").put("media_type", "image/jpeg").put("data", b64)))
            .put(JSONObject().put("type", "text").put("text", note))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 800)
            .put("system", SYSTEM_PROMPT)
            .put("tools", JSONArray().put(toolJson()))
            .put("tool_choice", JSONObject().put("type", "tool").put("name", "act"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 90000
        conn.doOutput = true
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.setRequestProperty("content-type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().readText()
        if (code != 200) throw Exception("HTTP $code: " + text.take(250))
        val arr = JSONObject(text).getJSONArray("content")
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.getString("type") == "tool_use") return b.getJSONObject("input")
        }
        return JSONObject().put("screen_state", "unknown").put("observation", "")
            .put("reasoning", "no tool call").put("action", "wait")
    }

    private fun loop() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val key = p.getString("key", "") ?: ""
        val model = (p.getString("model", "") ?: "").ifBlank { "claude-sonnet-5-5" }
        val dry = p.getBoolean("dry", false)
        if (key.isBlank()) { log("No API key. Enter it in the app first."); running = false; return }
        val history = ArrayList<String>()
        var lastHash = 0
        var n = 0
        log("Started with " + model + (if (dry) " (dry run)" else ""))
        while (running) {
            n++
            val shot = capture()
            if (shot == null) { log("Screenshot failed, retrying..."); Thread.sleep(2000); continue }
            val scale = shot.width / SEND_WIDTH.toFloat()
            val small = Bitmap.createScaledBitmap(shot, SEND_WIDTH, (shot.height / scale).toInt(), true)
            val tiny = Bitmap.createScaledBitmap(small, 54, 120, false)
            val px = IntArray(54 * 120)
            tiny.getPixels(px, 0, 54, 0, 0, 54, 120)
            val hash = px.contentHashCode()
            val stuck = hash == lastHash
            lastHash = hash
            val bos = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)

            var note = ""
            if (history.isNotEmpty()) note += "Your last actions:\n" + history.takeLast(6).joinToString("\n") + "\n"
            if (stuck) note += "WARNING: the screen did not change after your last tap. Try something different or wait.\n"
            note += "Image size: ${small.width}x${small.height}. Decide the next action."

            val d: JSONObject
            try {
                d = ask(key, model, b64, note)
            } catch (e: Exception) {
                log("API error: " + e.message)
                Thread.sleep(5000)
                continue
            }
            if (!running) break
            var action = d.optString("action", "wait")
            val state = d.optString("screen_state", "unknown")
            var reasoning = d.optString("reasoning", "")
            var tapped = false
            if (action == "tap" && d.has("x") && d.has("y")) {
                val x = d.getInt("x")
                val y = d.getInt("y")
                val fy = y / small.height.toFloat()
                val menuLike = state == "menu" || state == "win" || state == "fail" || state == "popup"
                if (fy < 0.09f || fy > 0.93f || (fy > 0.90f && !menuLike)) {
                    reasoning += " [BLOCKED by safety rail]"
                    action = "wait"
                } else {
                    tapped = true
                    if (!dry) tap(x * scale, y * scale)
                }
            }
            history.add("#$n $state: $action ${d.optString("x")},${d.optString("y")} - " + reasoning.take(90))
            log("#$n [$state] $action ${if (tapped) d.optString("x") + "," + d.optString("y") else ""} | $reasoning")
            Thread.sleep(if (tapped) 1000 else 1500)
        }
    }
}
